"use client";

import React, { useState } from "react";
import { MapPin, Clock, Calendar, Send } from "lucide-react";

const Contact = () => {
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    service: "",
    message: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus("loading");

    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: `${form.firstName} ${form.lastName}`.trim(),
          email: form.email,
          phone: form.phone,
          service: form.service,
          message: form.message,
        }),
      });

      if (res.ok) {
        setStatus("success");
        setForm({ firstName: "", lastName: "", email: "", phone: "", service: "", message: "" });
      } else {
        setStatus("error");
      }
    } catch {
      setStatus("error");
    }
  };

  return (
    <section id="contact" className="py-28 px-6 bg-[#F9F5F0]">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16 flex flex-col items-center gap-5">
          <p className="text-[0.62rem] tracking-[0.34em] uppercase text-[#c9a96e] font-medium font-body">
            Genève · Sur rendez-vous
          </p>
          <h2 className="text-[2.6rem] md:text-[3rem] text-[#2c2826] font-display leading-[1.15]">
            Votre Renaissance <em className="italic-serif">commence ici.</em>
          </h2>
          <div className="ornament-divider w-56 my-2">
            <div className="ornament-line"></div>
            <span className="text-[#c9a96e] text-xs">✦</span>
            <div className="ornament-line"></div>
          </div>
          <p className="text-[0.95rem] leading-[1.9] text-[#6b5c4e] max-w-3xl text-center font-body tracking-[0.02em]">
            Consultations et soins sur rendez-vous uniquement, pour garantir votre intimité et un accompagnement entièrement personnalisé.
          </p>
        </div>

        <div className="grid lg:grid-cols-12 gap-12 items-start">
          <div className="lg:col-span-5 flex flex-col gap-6">
            <div className="bg-white p-8 rounded-sm shadow-[0_4px_20px_rgba(201,169,110,0.1)] flex gap-6 items-start transition-all duration-300 hover:shadow-[0_8px_30px_rgba(201,169,110,0.15)]">
              <div className="w-12 h-12 rounded-full border border-[#E8DDD0] flex items-center justify-center flex-shrink-0">
                <MapPin className="w-5 h-5 text-[#c9a96e]" />
              </div>
              <div>
                <h3 className="text-[0.7rem] tracking-[0.2em] uppercase text-[#2c2826] font-semibold mb-2 font-body">Localisation</h3>
                <p className="text-[0.86rem] text-[#6b5c4e] font-body leading-relaxed">Genève, Suisse</p>
                <p className="text-[0.74rem] text-[#a08878] font-body italic mt-1 leading-relaxed">
                  Adresse communiquée lors de la confirmation de rendez-vous
                </p>
              </div>
            </div>

            <div className="bg-white p-8 rounded-sm shadow-[0_4px_20px_rgba(201,169,110,0.1)] flex gap-6 items-start transition-all duration-300 hover:shadow-[0_8px_30px_rgba(201,169,110,0.15)]">
              <div className="w-12 h-12 rounded-full border border-[#E8DDD0] flex items-center justify-center flex-shrink-0">
                <Clock className="w-5 h-5 text-[#c9a96e]" />
              </div>
              <div className="flex-1">
                <h3 className="text-[0.7rem] tracking-[0.2em] uppercase text-[#2c2826] font-semibold mb-4 font-body">Horaires</h3>
                <div className="space-y-3 w-full">
                  <div className="flex justify-between items-center text-[0.86rem] font-body">
                    <span className="text-[#6b5c4e]">Lundi - Vendredi</span>
                    <span className="text-[#2c2826] font-medium">08h30 - 19h00</span>
                  </div>
                  <div className="flex justify-between items-center text-[0.86rem] font-body">
                    <span className="text-[#6b5c4e]">Samedi</span>
                    <span className="text-[#2c2826] font-medium">Sur demande</span>
                  </div>
                  <div className="flex justify-between items-center text-[0.86rem] font-body">
                    <span className="text-[#6b5c4e]">Dimanche</span>
                    <span className="text-[#a08878] italic">Fermé</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-sm shadow-[0_4px_20px_rgba(201,169,110,0.1)] flex gap-6 items-start transition-all duration-300 hover:shadow-[0_8px_30px_rgba(201,169,110,0.15)]">
              <div className="w-12 h-12 rounded-full border border-[#E8DDD0] flex items-center justify-center flex-shrink-0">
                <Calendar className="w-5 h-5 text-[#c9a96e]" />
              </div>
              <div>
                <h3 className="text-[0.7rem] tracking-[0.2em] uppercase text-[#2c2826] font-semibold mb-2 font-body">Rendez-vous uniquement</h3>
                <p className="text-[0.86rem] text-[#6b5c4e] font-body leading-relaxed">
                  Pour garantir votre intimité, le cabinet ne reçoit pas sans rendez-vous préalable.
                </p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7">
            <div className="bg-white p-10 rounded-sm shadow-[0_4px_40px_rgba(201,169,110,0.1)] transition-all duration-500 hover:shadow-[0_8px_50px_rgba(201,169,110,0.15)]">
              {status === "success" ? (
                <div className="py-16 flex flex-col items-center gap-6 text-center">
                  <span className="text-3xl text-[#c9a96e]">✦</span>
                  <h3 className="text-2xl text-[#2c2826] font-display">Message bien reçu</h3>
                  <p className="text-[0.86rem] text-[#6b5c4e] font-body leading-relaxed max-w-sm">
                    Merci pour votre confiance. Je vous répondrai dans les plus brefs délais pour confirmer votre rendez-vous.
                  </p>
                  <button
                    onClick={() => setStatus("idle")}
                    className="mt-4 text-[0.65rem] tracking-[0.2em] uppercase text-[#c9a96e] border-b border-[#c9a96e] pb-0.5 font-body"
                  >
                    Envoyer un autre message
                  </button>
                </div>
              ) : (
                <>
                  <div className="flex items-center gap-3 mb-8">
                    <h3 className="text-2xl text-[#2c2826] font-display">Envoyer un message</h3>
                    <div className="h-px flex-grow bg-[#E8DDD0]"></div>
                  </div>

                  <form className="space-y-6" onSubmit={handleSubmit}>
                    <div className="grid sm:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-[0.65rem] tracking-[0.2em] uppercase text-[#6b5c4e] font-semibold block font-body">Prénom</label>
                        <input
                          name="firstName"
                          type="text"
                          value={form.firstName}
                          onChange={handleChange}
                          placeholder="Votre prénom"
                          required
                          className="w-full bg-[#f9f5f0]/50 border border-[#E8DDD0] p-4 text-[0.86rem] font-body focus:outline-none focus:border-[#c9a96e] transition-colors rounded-sm text-[#2c2826] placeholder:text-[#a08878]/60"
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="text-[0.65rem] tracking-[0.2em] uppercase text-[#6b5c4e] font-semibold block font-body">Nom</label>
                        <input
                          name="lastName"
                          type="text"
                          value={form.lastName}
                          onChange={handleChange}
                          placeholder="Votre nom"
                          required
                          className="w-full bg-[#f9f5f0]/50 border border-[#E8DDD0] p-4 text-[0.86rem] font-body focus:outline-none focus:border-[#c9a96e] transition-colors rounded-sm text-[#2c2826] placeholder:text-[#a08878]/60"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[0.65rem] tracking-[0.2em] uppercase text-[#6b5c4e] font-semibold block font-body">Email *</label>
                      <input
                        name="email"
                        type="email"
                        value={form.email}
                        onChange={handleChange}
                        placeholder="votre@email.com"
                        required
                        className="w-full bg-[#f9f5f0]/50 border border-[#E8DDD0] p-4 text-[0.86rem] font-body focus:outline-none focus:border-[#c9a96e] transition-colors rounded-sm text-[#2c2826] placeholder:text-[#a08878]/60"
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-[0.65rem] tracking-[0.2em] uppercase text-[#6b5c4e] font-semibold block font-body">Téléphone</label>
                      <input
                        name="phone"
                        type="tel"
                        value={form.phone}
                        onChange={handleChange}
                        placeholder="+41 00 000 00 00"
                        className="w-full bg-[#f9f5f0]/50 border border-[#E8DDD0] p-4 text-[0.86rem] font-body focus:outline-none focus:border-[#c9a96e] transition-colors rounded-sm text-[#2c2826] placeholder:text-[#a08878]/60"
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-[0.65rem] tracking-[0.2em] uppercase text-[#6b5c4e] font-semibold block font-body">Prestation souhaitée</label>
                      <select
                        name="service"
                        value={form.service}
                        onChange={handleChange}
                        className="w-full bg-[#f9f5f0]/50 border border-[#E8DDD0] p-4 text-[0.86rem] font-body focus:outline-none focus:border-[#c9a96e] transition-colors rounded-sm text-[#2c2826] appearance-none cursor-pointer"
                      >
                        <option value="">Sélectionner une prestation</option>
                        <option value="Reconstruction Aréolaire 3D — Unilatérale (750 CHF)">Reconstruction Aréolaire — Unilatérale (750 CHF)</option>
                        <option value="Reconstruction Aréolaire 3D — Bilatérale (950 CHF)">Reconstruction Aréolaire — Bilatérale (950 CHF)</option>
                        <option value="Moulage des Tétons — Sur mesure (devis)">Moulage des Tétons — Sur mesure</option>
                        <option value="Camouflage Correctif (dès 400 CHF)">Camouflage Correctif (dès 400 CHF)</option>
                        <option value="Sublimation des Lèvres — Candy Lips (550 CHF)">Sublimation des Lèvres — Candy Lips (550 CHF)</option>
                        <option value="Formation Certifiante (600 CHF)">Formation Certifiante (600 CHF)</option>
                      </select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[0.65rem] tracking-[0.2em] uppercase text-[#6b5c4e] font-semibold block font-body">Message *</label>
                      <textarea
                        name="message"
                        rows={5}
                        value={form.message}
                        onChange={handleChange}
                        placeholder="Décrivez votre demande, vos disponibilités…"
                        required
                        className="w-full bg-[#f9f5f0]/50 border border-[#E8DDD0] p-4 text-[0.86rem] font-body focus:outline-none focus:border-[#c9a96e] transition-colors rounded-sm text-[#2c2826] placeholder:text-[#a08878]/60 resize-none"
                      />
                    </div>

                    {status === "error" && (
                      <p className="text-xs text-red-400 text-center font-body">
                        Une erreur est survenue. Veuillez réessayer ou me contacter directement.
                      </p>
                    )}

                    <button
                      type="submit"
                      disabled={status === "loading"}
                      className="w-full bg-[#c9a96e] py-5 text-white text-[0.7rem] tracking-[0.28em] uppercase font-bold rounded-sm flex items-center justify-center gap-3 hover:bg-[#b8945a] transition-all duration-300 shadow-[0_4px_20px_rgba(201,169,110,0.3)] mt-4 disabled:opacity-60 font-body"
                    >
                      {status === "loading" ? "Envoi en cours…" : <>Envoyer ma demande <Send className="w-3 h-3" /></>}
                    </button>
                  </form>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
