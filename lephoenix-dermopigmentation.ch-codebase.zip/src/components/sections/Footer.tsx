import React from 'react';

const PhoenixLogo = ({ className }: { className?: string }) => (
  <svg
    className={className}
    viewBox="0 0 36 40"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    aria-label="Le Phoenix Logo"
  >
    <path d="M18 2L14 6L18 10L22 6L18 2Z" fill="#c9a96e" />
    <path d="M18 12V38" stroke="#c9a96e" strokeWidth="0.5" />
    <path d="M10 15C8 18 8 22 10 25" stroke="#c9a96e" strokeWidth="0.5" />
    <path d="M26 15C28 18 28 22 26 25" stroke="#c9a96e" strokeWidth="0.5" />
    <path d="M6 18C4 22 4 28 6 32" stroke="#c9a96e" strokeWidth="0.5" />
    <path d="M30 18C32 22 32 28 30 32" stroke="#c9a96e" strokeWidth="0.5" />
    <circle cx="18" cy="15" r="1.5" fill="#c9a96e" />
    <circle cx="18" cy="22" r="1" fill="#c9a96e" />
    <path d="M14 30L18 34L22 30" stroke="#c9a96e" strokeWidth="0.5" fill="none" />
  </svg>
);

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#2C2826] text-white py-20 px-6 font-body">
      <div className="max-w-6xl mx-auto flex flex-col items-center">
        <div className="flex flex-col items-center mb-10 text-center">
          <PhoenixLogo className="w-12 h-14 mb-4" />
          <h2 className="text-[1.5rem] tracking-[0.15em] uppercase font-display text-white mb-1">
            Le Phoenix
          </h2>
          <p className="text-[0.55rem] tracking-[0.3em] uppercase text-[#A08878]">
            Dermopigmentation · Genève
          </p>
        </div>

        <div className="ornament-divider w-full max-w-[200px] mb-12">
          <div className="h-px bg-[#c9a96e] opacity-30 flex-grow"></div>
          <span className="text-[#c9a96e] text-[10px] px-4">✦</span>
          <div className="h-px bg-[#c9a96e] opacity-30 flex-grow"></div>
        </div>

        <nav className="flex flex-wrap justify-center gap-x-10 gap-y-4 mb-16 font-body">
          <a href="#accueil" className="text-[0.68rem] tracking-[0.18em] uppercase text-[#A08878] hover:text-[#c9a96e] transition-colors duration-300">
            Accueil
          </a>
          <a href="#about" className="text-[0.68rem] tracking-[0.18em] uppercase text-[#A08878] hover:text-[#c9a96e] transition-colors duration-300">
            À propos
          </a>
          <a href="#prestations" className="text-[0.68rem] tracking-[0.18em] uppercase text-[#A08878] hover:text-[#c9a96e] transition-colors duration-300">
            Prestations
          </a>
          <a href="#engagement" className="text-[0.68rem] tracking-[0.18em] uppercase text-[#A08878] hover:text-[#c9a96e] transition-colors duration-300">
            Engagement
          </a>
          <a href="#contact" className="text-[0.68rem] tracking-[0.18em] uppercase text-[#A08878] hover:text-[#c9a96e] transition-colors duration-300">
            Contact
          </a>
        </nav>

        <div className="w-full h-px bg-white/5 mb-8"></div>

        <div className="w-full flex flex-col md:flex-row justify-between items-center gap-6 text-[0.65rem] tracking-widest uppercase text-[#6B5C4E]">
          <div className="order-2 md:order-1">© {currentYear} Le Phoenix — Tous droits réservés.</div>
          <div className="order-1 md:order-2 italic font-display text-[0.75rem] lowercase tracking-normal flex items-center gap-2">
            <span className="not-italic text-[0.65rem] uppercase tracking-widest text-[#6B5C4E]">Cabinet sur rendez-vous ·</span>
            <span className="text-[#A08878]">Genève, Suisse</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
