import React from 'react';

const About = () => {
  return (
    <section
      id="about"
      className="py-[112px] px-6 bg-[#F9F5F0]"
      style={{ isolation: 'isolate' }}
    >
      <div className="container max-w-[1024px] mx-auto grid lg:grid-cols-2 gap-16 lg:gap-24 items-center">
        {/* Left Column: Decorative Quote Card */}
        <div className="relative flex items-center justify-center order-2 lg:order-1">
          {/* Main Quote Card */}
          <div className="relative w-full aspect-[4/5] max-w-[400px] bg-[#FDFBF6] border border-[#E8DDD0] p-1 shadow-sm overflow-hidden group">
            {/* Inner Border/Accent Box */}
            <div className="absolute inset-4 border border-[#E8DDD0] opacity-60 pointer-events-none" />
            
            {/* Background Texture/Gradient Subtle Overlay */}
            <div className="absolute inset-0 bg-gradient-to-tr from-[#C9A96E]/5 to-transparent pointer-events-none" />

            {/* Content Container */}
            <div className="relative h-full flex flex-col items-center justify-center p-12 text-center gap-8">
              {/* Decorative Icon */}
              <div className="opacity-30 mb-2">
                <svg
                  width="48"
                  height="56"
                  viewBox="0 0 48 56"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="text-[#C9A96E]"
                >
                  <path
                    d="M24 0L26.5 21.5L48 24L26.5 26.5L24 48L21.5 26.5L0 24L21.5 21.5L24 0Z"
                    fill="currentColor"
                  />
                  <circle cx="24" cy="24" r="2" fill="#F9F5F0" />
                </svg>
              </div>

              {/* Quote Text */}
              <blockquote className="text-[24px] md:text-[28px] leading-relaxed text-[#2C2826] font-display italic">
                “Transformer l’épreuve en renaissance.”
              </blockquote>

              {/* Gold Divider */}
              <div className="w-10 h-px bg-[#C9A96E] opacity-50" />

              {/* Author Attribution */}
              <cite className="not-italic text-[10px] tracking-[0.3em] uppercase text-[#C9A96E] font-body font-medium">
                Myriam — Le Phoenix
              </cite>
            </div>
          </div>

          {/* Background Decorative Accent - Ghost Box Offset */}
          <div className="absolute -bottom-6 -right-6 w-32 h-32 border-b border-r border-[#E8DDD0] -z-10 hidden lg:block" />
          <div className="absolute -top-6 -left-6 w-32 h-32 border-t border-l border-[#E8DDD0] -z-10 hidden lg:block" />
        </div>

        {/* Right Column: Storytelling Text */}
        <div className="order-1 lg:order-2 flex flex-col gap-8">
            <div className="flex flex-col gap-4">
              <span className="text-[0.62rem] tracking-[0.34em] uppercase text-[#C9A96E] font-body font-semibold">
                À propos de moi
              </span>
              <h2 className="text-[2.5rem] md:text-[3rem] text-[#2C2826] leading-[1.15] font-display">
                Une vocation née de
                <br />
                <span className="italic">l’amour & du combat.</span>
              </h2>

            <div className="w-12 h-px bg-[#C9A96E] mt-2" />
          </div>

          <div className="flex flex-col gap-6">
            <p className="text-[0.95rem] leading-[1.95] text-[#6B5C4E] font-body tracking-[0.02em]">
              Le Phoenix est né d’une volonté profonde : transformer l’épreuve en renaissance. 
              Fortement marquée par le combat de ma maman contre le cancer, j’ai vu à quel 
              point la perte de repères corporels est une étape difficile.
            </p>
            <p className="text-[0.95rem] leading-[1.95] text-[#6B5C4E] font-body tracking-[0.02em]">
              C’est pour honorer sa mémoire et offrir à chaque personne la chance de se 
              réapproprier son image que j’ai fondé ce cabinet. Je mets mon expertise et ma 
              bienveillance à votre service, pour que vous puissiez vous regarder à nouveau 
              avec amour et confiance.
            </p>
          </div>

          <div className="mt-4">
            <p className="text-[20px] font-display italic text-[#2C2826]">
              Myriam
            </p>
            <div className="w-8 h-px bg-[#E8DDD0] mt-4" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;