import React from 'react';
import Image from 'next/image';

const services = [
  {
    category: "Reconstruction",
    title: "Reconstruction Esthétique Aréolaire",
    description:
      "Création d'aréoles mammaires 3D en trompe-l'œil et moulages personnalisés pour une symétrie restaurée après une chirurgie.",
    image:
      "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/project-uploads/a33b328f-c0bd-4f54-ad79-6fbc87ee2262/getty-images-559zHyVYKts-unsplash-1771787710928.jpg?width=800&height=600&resize=cover",
    pricing: [
      { label: "Unilatérale", price: "750 CHF" },
      { label: "Bilatérale", price: "950 CHF" },
    ],
    note: "Retouche incluse dans les 8 semaines suivant la séance",
  },
  {
    category: "Reconstruction",
    title: "Moulage des Tétons",
    description:
      "Réalisation de prothèses de tétons sur mesure en silicone, pour une reconstruction douce et personnalisée, adaptée à chaque morphologie.",
    image:
      "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/project-uploads/a33b328f-c0bd-4f54-ad79-6fbc87ee2262/2-Pink-Gallery-1771787605816.jpg?width=800&height=600&resize=cover",
    pricing: [
      { label: "Unilatéral", price: "420 CHF" },
      { label: "Bilatéral", price: "700 CHF" },
    ],
    note: "Consultation offerte — tarifs Genève, Suisse",
  },
  {
    category: "Correction",
    title: "Camouflage Correctif",
    description:
      "Atténuation visuelle experte des cicatrices, vergetures et zones de vitiligo par pigmentation de précision.",
    image:
      "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/project-uploads/a33b328f-c0bd-4f54-ad79-6fbc87ee2262/cc0ddf0984d134b188d9c9ff5f3312f2-1771787728846.jpg?width=800&height=600&resize=cover",
    pricing: [{ label: "Dès", price: "400 CHF / séance" }],
    note: "Devis sur consultation selon la zone — cicatrices, vitiligo, vergetures",
  },
  {
    category: "Esthétique",
    title: "Sublimation des Lèvres",
    description:
      "Redéfinition et mise en couleur pour un éclat naturel, grâce à la technique Candy Lips.",
    image:
      "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/project-uploads/a33b328f-c0bd-4f54-ad79-6fbc87ee2262/a5535331f9dde4832f59be27002e509f-1771787671869.jpg?width=800&height=600&resize=cover",
    pricing: [{ label: "Candy Lips", price: "550 CHF" }],
    note: "Retouche incluse dans le forfait initial",
  },
  {
    category: "Formation",
    title: "Formation Permanent Make-Up",
    description:
      "Formation en Hygiène, Salubrité et Secourisme, dédiée aux professionnels du tatouage et du maquillage permanent. Journée complète avec attestation.",
    image:
      "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/project-uploads/a33b328f-c0bd-4f54-ad79-6fbc87ee2262/3eab51eeb5cf69d078bb79e15fef65c0-1771787690075.jpg?width=800&height=600&resize=cover",
    pricing: [{ label: "Session (1 journée)", price: "600 CHF" }],
    note: "Attestation de participation remise en fin de journée",
  },
];

export default function ServicesSection() {
  return (
    <section id="prestations" className="py-28 px-6 bg-[#F9F5F0]">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16 flex flex-col items-center gap-5">
          <p className="text-[0.62rem] font-medium tracking-[0.34em] uppercase text-[#C9A96E] font-body">
            Expertise & Savoir-faire
          </p>
          <h2 className="text-[2.6rem] md:text-[3rem] text-[#2C2826] font-display leading-[1.15]">
            Mes Prestations & <em className="italic italic-serif font-display">Tarifs</em>
          </h2>
          <div className="ornament-divider w-56">
            <div className="ornament-line"></div>
            <span className="text-[#C9A96E] text-xs">✦</span>
            <div className="ornament-line"></div>
          </div>
          <p className="text-[0.95rem] leading-[1.9] text-[#6B5C4E] max-w-2xl text-center font-body tracking-[0.02em]">
            Chaque soin est précédé d’une consultation individuelle pour un accompagnement entièrement personnalisé.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <article
              key={index}
              className="group relative bg-[#FFFFFF] rounded-sm flex flex-col overflow-hidden hover:shadow-[0_8px_40px_rgba(201,169,110,0.18)] transition-all duration-400 border border-[#E8DDD0]/30"
            >
              <div className="relative overflow-hidden h-[240px]">
                <Image
                  src={service.image}
                  alt={service.title}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-105"
                  sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                />
                <div className="absolute inset-0 bg-[#2C2826]/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <span className="absolute top-4 left-4 px-3 py-1 text-[0.6rem] tracking-[0.24em] font-medium uppercase text-[#FFFFFF] bg-[#C9A96E] rounded-sm font-body">
                  {service.category}
                </span>
              </div>

              <div className="p-7 flex flex-col gap-4 flex-1">
                <h3 className="text-[1.35rem] text-[#2C2826] font-display leading-snug">
                  {service.title}
                </h3>
                <div className="w-8 h-[1px] bg-[#E8DDD0] group-hover:bg-[#C9A96E] transition-colors duration-300"></div>
                <p className="text-[0.92rem] leading-[1.8] text-[#6B5C4E] flex-1 font-body tracking-[0.02em]">
                  {service.description}
                </p>

                <div className="mt-auto pt-6 border-t border-[#F0E8DC] flex flex-col gap-2">
                  {service.pricing.map((item, pIndex) => (
                    <div key={pIndex} className="flex items-center justify-between">
                      <span className="text-[0.65rem] tracking-[0.14em] uppercase text-[#A08878] font-body font-medium">
                        {item.label}
                      </span>
                      <span className="text-[0.95rem] font-semibold text-[#B8945A] font-body">
                        {item.price}
                      </span>
                    </div>
                  ))}
                  <div className="pt-2">
                    <p className="text-[0.7rem] leading-relaxed tracking-[0.02em] text-[#A08878] italic font-body">
                      {service.note}
                    </p>
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>

        <div className="mt-16 text-center space-y-8">
          <p className="text-[0.78rem] tracking-[0.08em] text-[#A08878] font-body">
            Toutes les prestations incluent une consultation préalable offerte.
          </p>
          <div className="flex justify-center">
            <a
              href="#contact"
              className="px-10 py-4 bg-[#C9A96E] text-[#FFFFFF] text-[0.62rem] font-semibold tracking-[0.25em] uppercase hover:bg-[#B8945A] transition-all duration-300 rounded-sm shadow-[0_4px_20px_rgba(201,169,110,0.15)]"
            >
              Prendre rendez-vous
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
