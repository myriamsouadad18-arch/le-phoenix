"use client";

import React, { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";

const PhoenixLogo = ({ className }: { className?: string }) => (
  <svg
    className={className}
    viewBox="0 0 100 100"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    aria-label="Le Phoenix Logo"
  >
    {/* === FLAMMES === */}
    <path d="M50 95 C47 88 44 82 46 74 C42 79 40 86 42 92" stroke="currentColor" strokeWidth="1" strokeLinecap="round" fill="none" opacity="0.45"/>
    <path d="M50 95 C53 88 56 82 54 74 C58 79 60 86 58 92" stroke="currentColor" strokeWidth="1" strokeLinecap="round" fill="none" opacity="0.45"/>
    <path d="M50 93 C50 86 50 80 50 73" stroke="currentColor" strokeWidth="1" strokeLinecap="round" fill="none" opacity="0.5"/>
    <path d="M44 88 C41 83 39 76 42 70" stroke="currentColor" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.3"/>
    <path d="M56 88 C59 83 61 76 58 70" stroke="currentColor" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.3"/>

    {/* === CORPS === */}
    <ellipse cx="50" cy="58" rx="7" ry="11" stroke="currentColor" strokeWidth="1.2" fill="none"/>

    {/* === AILE GAUCHE === */}
    {/* Contour principal */}
    <path d="M43 55 C36 48 22 44 8 38 C13 43 11 50 16 53 C9 51 4 56 6 63 C11 58 16 61 21 58 C14 64 13 72 18 76 C23 68 30 65 35 62 C28 70 29 77 34 81 C39 72 43 67 43 63" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    {/* Plumes détails */}
    <path d="M20 52 C25 50 30 53 32 58" stroke="currentColor" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.55"/>
    <path d="M13 60 C18 57 24 60 26 65" stroke="currentColor" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.55"/>
    <path d="M17 70 C22 67 27 70 28 75" stroke="currentColor" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.55"/>

    {/* === AILE DROITE === */}
    <path d="M57 55 C64 48 78 44 92 38 C87 43 89 50 84 53 C91 51 96 56 94 63 C89 58 84 61 79 58 C86 64 87 72 82 76 C77 68 70 65 65 62 C72 70 71 77 66 81 C61 72 57 67 57 63" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    <path d="M80 52 C75 50 70 53 68 58" stroke="currentColor" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.55"/>
    <path d="M87 60 C82 57 76 60 74 65" stroke="currentColor" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.55"/>
    <path d="M83 70 C78 67 73 70 72 75" stroke="currentColor" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.55"/>

    {/* === COU === */}
    <path d="M45 47 C44 40 45 33 50 27" stroke="currentColor" strokeWidth="1.1" strokeLinecap="round" fill="none"/>
    <path d="M55 47 C56 40 55 33 50 27" stroke="currentColor" strokeWidth="1.1" strokeLinecap="round" fill="none"/>

    {/* === TÊTE === */}
    <circle cx="50" cy="22" r="7" stroke="currentColor" strokeWidth="1.2" fill="none"/>

    {/* === BEC === */}
    <path d="M50 19 L56 17 L50 22" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" fill="none"/>

    {/* === ŒIL === */}
    <circle cx="52" cy="21" r="1.2" fill="currentColor"/>

    {/* === CRÊTE / COURONNE — 5 rayons === */}
    <path d="M46 16 C44 10 46 5 50 2" stroke="currentColor" strokeWidth="1" strokeLinecap="round" fill="none"/>
    <path d="M48 15 C47 9 48 4 50 2" stroke="currentColor" strokeWidth="1" strokeLinecap="round" fill="none"/>
    <path d="M50 15 C50 9 50 3 50 1" stroke="currentColor" strokeWidth="1.1" strokeLinecap="round" fill="none"/>
    <path d="M52 15 C53 9 52 4 50 2" stroke="currentColor" strokeWidth="1" strokeLinecap="round" fill="none"/>
    <path d="M54 16 C56 10 54 5 50 2" stroke="currentColor" strokeWidth="1" strokeLinecap="round" fill="none"/>
    <circle cx="46" cy="15" r="1" fill="currentColor" opacity="0.8"/>
    <circle cx="48.5" cy="14" r="1" fill="currentColor" opacity="0.8"/>
    <circle cx="50" cy="13.5" r="1.1" fill="currentColor"/>
    <circle cx="51.5" cy="14" r="1" fill="currentColor" opacity="0.8"/>
    <circle cx="54" cy="15" r="1" fill="currentColor" opacity="0.8"/>

    {/* === QUEUE === */}
    <path d="M45 69 C42 75 37 80 34 88" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" fill="none"/>
    <path d="M50 70 C50 77 50 82 50 90" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" fill="none"/>
    <path d="M55 69 C58 75 63 80 66 88" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" fill="none"/>
    <path d="M47 70 C45 76 43 81 40 87" stroke="currentColor" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.5"/>
    <path d="M53 70 C55 76 57 81 60 87" stroke="currentColor" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.5"/>
  </svg>
);

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Accueil", href: "#accueil" },
    { name: "À propos", href: "#about" },
    { name: "Prestations", href: "#prestations" },
    { name: "Engagement", href: "#engagement" },
    { name: "Contact", href: "#contact" },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled ? "bg-white/95 backdrop-blur-sm shadow-sm" : "bg-transparent"
      }`}
    >
      <div className="max-w-6xl mx-auto px-6 flex items-center justify-between h-20">
        <a href="#accueil" className="flex items-center gap-3 group">
            <PhoenixLogo className="w-10 h-11 text-[#C9A96E] transition-opacity group-hover:opacity-80" />
          <div className="leading-tight">
              <span className="block text-[1.35rem] tracking-[0.1em] uppercase font-display text-[#2c2826]">
                Le Phoenix
              </span>
              <span className="block text-[0.56rem] tracking-[0.2em] uppercase font-body text-[#6b5c4e]">
                Dermopigmentation · Genève
              </span>
          </div>
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="text-[0.7rem] tracking-[0.2em] uppercase text-[#6b5c4e] hover:text-[#c9a96e] transition-colors duration-200 font-body"
            >
              {link.name}
            </a>
          ))}
          <a
            href="#contact"
            className="ml-2 px-5 py-2 text-[0.65rem] tracking-[0.2em] uppercase border border-[#c9a96e] text-[#c9a96e] hover:bg-[#c9a96e] hover:text-white transition-all duration-300 rounded-sm font-body font-semibold"
          >
            Prendre RDV
          </a>
        </nav>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden flex flex-col items-center justify-center p-2 text-[#c9a96e]"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          aria-label="Menu"
        >
          {mobileMenuOpen ? (
            <X className="w-6 h-6" />
          ) : (
            <div className="flex flex-col gap-1.5">
              <span className="block w-5 h-px bg-[#c9a96e]"></span>
              <span className="block w-5 h-px bg-[#c9a96e]"></span>
              <span className="block w-5 h-px bg-[#c9a96e]"></span>
            </div>
          )}
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      <div
        className={`fixed inset-0 bg-[#F9F5F0] z-40 transition-transform duration-500 ease-in-out md:hidden ${
          mobileMenuOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex flex-col items-center justify-center h-full gap-8 p-6">
          <button 
            className="absolute top-6 right-6 p-2 text-[#c9a96e]"
            onClick={() => setMobileMenuOpen(false)}
          >
            <X className="w-8 h-8" />
          </button>
          
          <div className="mb-8 flex flex-col items-center gap-4">
               <PhoenixLogo className="w-14 h-16 text-[#C9A96E]" />
             <div className="text-center">
                <span className="block text-2xl tracking-[0.15em] uppercase font-display text-[#2c2826]">
                  Le Phoenix
                </span>
                <div className="w-8 h-px bg-[#c9a96e] mx-auto my-2"></div>
                <span className="block text-[0.6rem] tracking-[0.3em] uppercase font-body text-[#6b5c4e]">
                  Dermopigmentation · Genève
                </span>
             </div>
          </div>

          <nav className="flex flex-col items-center gap-6">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="text-sm tracking-[0.25em] uppercase text-[#6b5c4e] hover:text-[#c9a96e] transition-colors duration-200 font-body"
              >
                {link.name}
              </a>
            ))}
            <a
              href="#contact"
              onClick={() => setMobileMenuOpen(false)}
              className="mt-4 px-10 py-4 text-[0.7rem] tracking-[0.3em] uppercase bg-[#c9a96e] text-white rounded-sm font-body font-bold"
            >
              Prendre RDV
            </a>
          </nav>
        </div>
      </div>
    </header>
  );
}