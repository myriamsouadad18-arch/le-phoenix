import React from 'react';

export default function Hero() {
  return (
    <section
      id="accueil"
      className="relative min-h-screen flex items-center justify-center overflow-hidden bg-[#FDF0E2]/10"
      style={{
        background: 'radial-gradient(circle at center, #FDF0E2 0%, #F9F5F0 100%)',
      }}
    >
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#C9A96E]/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-20 right-20 w-[300px] h-[300px] bg-[#FFFFFF]/40 rounded-full blur-[80px] pointer-events-none hidden lg:block" />

      <div className="relative z-10 text-center px-6 mx-auto flex flex-col items-center gap-8 pt-28 pb-20 max-w-[680px] w-full">
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-1000 ease-out fill-mode-forwards">
          <svg
            className="w-24 h-24 mx-auto"
            viewBox="0 0 100 100"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            aria-label="Le Phoenix Logo"
          >
            <path d="M50 95 C47 88 44 82 46 74 C42 79 40 86 42 92" stroke="#C9A96E" strokeWidth="1" strokeLinecap="round" fill="none" opacity="0.45" />
            <path d="M50 95 C53 88 56 82 54 74 C58 79 60 86 58 92" stroke="#C9A96E" strokeWidth="1" strokeLinecap="round" fill="none" opacity="0.45" />
            <path d="M50 93 C50 86 50 80 50 73" stroke="#C9A96E" strokeWidth="1" strokeLinecap="round" fill="none" opacity="0.5" />
            <path d="M44 88 C41 83 39 76 42 70" stroke="#C9A96E" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.3" />
            <path d="M56 88 C59 83 61 76 58 70" stroke="#C9A96E" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.3" />
            <ellipse cx="50" cy="58" rx="7" ry="11" stroke="#C9A96E" strokeWidth="1.2" fill="none" />
            <path d="M43 55 C36 48 22 44 8 38 C13 43 11 50 16 53 C9 51 4 56 6 63 C11 58 16 61 21 58 C14 64 13 72 18 76 C23 68 30 65 35 62 C28 70 29 77 34 81 C39 72 43 67 43 63" stroke="#C9A96E" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" fill="none" />
            <path d="M20 52 C25 50 30 53 32 58" stroke="#C9A96E" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.55" />
            <path d="M13 60 C18 57 24 60 26 65" stroke="#C9A96E" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.55" />
            <path d="M17 70 C22 67 27 70 28 75" stroke="#C9A96E" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.55" />
            <path d="M57 55 C64 48 78 44 92 38 C87 43 89 50 84 53 C91 51 96 56 94 63 C89 58 84 61 79 58 C86 64 87 72 82 76 C77 68 70 65 65 62 C72 70 71 77 66 81 C61 72 57 67 57 63" stroke="#C9A96E" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" fill="none" />
            <path d="M80 52 C75 50 70 53 68 58" stroke="#C9A96E" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.55" />
            <path d="M87 60 C82 57 76 60 74 65" stroke="#C9A96E" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.55" />
            <path d="M83 70 C78 67 73 70 72 75" stroke="#C9A96E" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.55" />
            <path d="M45 47 C44 40 45 33 50 27" stroke="#C9A96E" strokeWidth="1.1" strokeLinecap="round" fill="none" />
            <path d="M55 47 C56 40 55 33 50 27" stroke="#C9A96E" strokeWidth="1.1" strokeLinecap="round" fill="none" />
            <circle cx="50" cy="22" r="7" stroke="#C9A96E" strokeWidth="1.2" fill="none" />
            <path d="M50 19 L56 17 L50 22" stroke="#C9A96E" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" fill="none" />
            <circle cx="52" cy="21" r="1.2" fill="#C9A96E" />
            <path d="M46 16 C44 10 46 5 50 2" stroke="#C9A96E" strokeWidth="1" strokeLinecap="round" fill="none" />
            <path d="M48 15 C47 9 48 4 50 2" stroke="#C9A96E" strokeWidth="1" strokeLinecap="round" fill="none" />
            <path d="M50 15 C50 9 50 3 50 1" stroke="#C9A96E" strokeWidth="1.1" strokeLinecap="round" fill="none" />
            <path d="M52 15 C53 9 52 4 50 2" stroke="#C9A96E" strokeWidth="1" strokeLinecap="round" fill="none" />
            <path d="M54 16 C56 10 54 5 50 2" stroke="#C9A96E" strokeWidth="1" strokeLinecap="round" fill="none" />
            <circle cx="46" cy="15" r="1" fill="#C9A96E" opacity="0.8" />
            <circle cx="48.5" cy="14" r="1" fill="#C9A96E" opacity="0.8" />
            <circle cx="50" cy="13.5" r="1.1" fill="#C9A96E" />
            <circle cx="51.5" cy="14" r="1" fill="#C9A96E" opacity="0.8" />
            <circle cx="54" cy="15" r="1" fill="#C9A96E" opacity="0.8" />
            <path d="M45 69 C42 75 37 80 34 88" stroke="#C9A96E" strokeWidth="1.2" strokeLinecap="round" fill="none" />
            <path d="M50 70 C50 77 50 82 50 90" stroke="#C9A96E" strokeWidth="1.2" strokeLinecap="round" fill="none" />
            <path d="M55 69 C58 75 63 80 66 88" stroke="#C9A96E" strokeWidth="1.2" strokeLinecap="round" fill="none" />
            <path d="M47 70 C45 76 43 81 40 87" stroke="#C9A96E" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.5" />
            <path d="M53 70 C55 76 57 81 60 87" stroke="#C9A96E" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.5" />
          </svg>
        </div>

        <p className="animate-in fade-in slide-in-from-bottom-4 duration-1000 delay-200 ease-out fill-mode-forwards text-[0.62rem] tracking-[0.34em] uppercase text-[#C9A96E] font-medium font-body">
          Dermopigmentation Réparatrice & Esthétique · Genève
        </p>

        <h1 className="animate-in fade-in slide-in-from-bottom-6 duration-1000 delay-400 ease-out fill-mode-forwards font-display text-5xl md:text-6xl lg:text-7xl leading-[1.1] text-[#2C2826] text-balance">
          L’art de la renaissance
          <br />
          <span className="italic-serif text-[#C9A96E] sm:text-inherit">par la peau.</span>
        </h1>

        <div className="animate-in fade-in duration-1000 delay-600 ease-out fill-mode-forwards flex items-center justify-center gap-4 w-48">
          <div className="h-px bg-[#E8DDD0] flex-grow"></div>
          <span className="text-[#C9A96E] text-xs">✦</span>
          <div className="h-px bg-[#E8DDD0] flex-grow"></div>
        </div>

        <p className="animate-in fade-in slide-in-from-bottom-4 duration-1000 delay-800 ease-out fill-mode-forwards font-body text-[14px] sm:text-[15px] leading-[1.9] text-[#6B5C4E] text-center tracking-[0.02em] opacity-90 max-w-3xl mx-auto px-2">
          Spécialisée dans la repigmentation cutanée réparatrice et esthétique à Genève,
          je vous accompagne avec douceur et précision pour restaurer l'harmonie de votre corps.
          Mon approche allie technicité de pointe et sensibilité artistique, pour un résultat naturel et durable.
        </p>

        <div className="animate-in fade-in slide-in-from-bottom-4 duration-1000 delay-1000 ease-out fill-mode-forwards flex flex-col sm:flex-row gap-5 mt-4">
          <a
            href="#prestations"
            className="px-8 py-4 bg-[#C9A96E] text-white text-[0.62rem] font-semibold tracking-[0.25em] uppercase hover:bg-[#B8945A] transition-all duration-300 rounded-[2px] shadow-[0_4px_20px_rgba(201,169,110,0.3)] whitespace-nowrap font-body"
          >
            Découvrir mes prestations
          </a>
          <a
            href="#contact"
            className="px-8 py-4 border border-[#C9A96E] text-[#C9A96E] text-[0.62rem] font-semibold tracking-[0.25em] uppercase hover:bg-[#C9A96E] hover:text-white transition-all duration-300 rounded-[2px] whitespace-nowrap font-body"
          >
            Prendre rendez-vous
          </a>
        </div>
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-3 opacity-60 animate-bounce">
        <span className="text-[8px] tracking-[0.3em] uppercase text-[#C9A96E] font-medium">Découvrir</span>
        <div className="w-px h-12 bg-gradient-to-b from-[#C9A96E] to-transparent"></div>
      </div>
    </section>
  );
}
