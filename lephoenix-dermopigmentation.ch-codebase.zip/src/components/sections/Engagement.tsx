import React from 'react';
import { ShieldCheck, Beaker, Users, ClipboardCheck } from 'lucide-react';

const EngagementSection = () => {
  return (
    <section id="engagement" className="py-28 px-6 bg-[#F9F5F0]">
      <div className="max-w-[1152px] mx-auto">
        <div className="text-center mb-16 flex flex-col items-center gap-5">
          <p className="text-[0.62rem] font-medium tracking-[0.34em] uppercase text-[#C9A96E] font-body">
            Votre sécurité, ma priorité
          </p>
          <h2 className="text-[2.6rem] md:text-[3rem] text-[#2C2826] font-display leading-[1.15] text-center">
            Engagement, Sécurité
            <br />
            <span className="italic-serif">& Hygiène</span>
          </h2>
          <div className="ornament-divider w-56 flex items-center justify-center gap-4">
            <div className="h-px bg-[#E8DDD0] flex-grow max-w-[80px]"></div>
            <span className="text-[#C9A96E] text-xs">✦</span>
            <div className="h-px bg-[#E8DDD0] flex-grow max-w-[80px]"></div>
          </div>
          <p className="text-[0.95rem] leading-[1.9] text-[#6B5C4E] max-w-3xl text-center tracking-[0.02em] font-body">
            Votre sécurité est ma priorité absolue. Je travaille exclusivement avec du matériel à usage unique et des pigments certifiés conformes aux normes suisses les plus exigeantes en matière de sécurité chimique.
          </p>
        </div>

        <div className="relative mb-20">
          <div className="max-w-4xl mx-auto bg-white/40 border border-[#E8DDD0] p-10 md:p-16 text-center relative overflow-hidden rounded-sm">
            <span className="absolute top-6 left-8 text-6xl font-display text-[#C9A96E] opacity-10 select-none">"</span>

            <p className="text-[1.35rem] md:text-[1.5rem] leading-relaxed text-[#2C2826] font-display italic relative z-10 max-w-2xl mx-auto">
              Votre sécurité est ma priorité absolue. Je travaille exclusivement avec du matériel à usage unique et des pigments certifiés conformes aux normes suisses les plus exigeantes en matière de sécurité chimique.
            </p>

            <span className="absolute bottom-2 right-8 text-6xl font-display text-[#C9A96E] opacity-10 select-none">”</span>

            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-[radial-gradient(circle,rgba(201,169,110,0.05)_0%,transparent_70%)] pointer-events-none"></div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white p-8 border border-[#F0E8DC] hover:shadow-[0_4px_20px_rgba(201,169,110,0.1)] transition-all duration-300 flex flex-col items-center text-center rounded-sm">
            <div className="w-12 h-12 rounded-full bg-[#F9F5F0] flex items-center justify-center mb-6 border border-[#E8DDD0]">
              <ShieldCheck className="w-5 h-5 text-[#C9A96E]" strokeWidth={1.5} />
            </div>
            <h3 className="text-[1.02rem] font-display text-[#2C2826] mb-4">Matériel à usage unique</h3>
            <div className="w-6 h-px bg-[#C9A96E] mb-4 opacity-40"></div>
            <p className="text-[0.82rem] leading-7 text-[#6B5C4E] tracking-[0.02em] font-body">
              Chaque intervention utilise exclusivement du matériel stérile et à usage unique. Zéro compromis sur la sécurité.
            </p>
          </div>

          <div className="bg-white p-8 border border-[#F0E8DC] hover:shadow-[0_4px_20px_rgba(201,169,110,0.1)] transition-all duration-300 flex flex-col items-center text-center rounded-sm">
            <div className="w-12 h-12 rounded-full bg-[#F9F5F0] flex items-center justify-center mb-6 border border-[#E8DDD0]">
              <Beaker className="w-5 h-5 text-[#C9A96E]" strokeWidth={1.5} />
            </div>
            <h3 className="text-[1.02rem] font-display text-[#2C2826] mb-4">Pigments certifiés suisses</h3>
            <div className="w-6 h-px bg-[#C9A96E] mb-4 opacity-40"></div>
            <p className="text-[0.82rem] leading-7 text-[#6B5C4E] tracking-[0.02em] font-body">
              J&apos;utilise exclusivement des pigments certifiés conformes aux normes suisses les plus exigeantes en matière de biocompatibilité et de sécurité.
            </p>
          </div>

          <div className="bg-white p-8 border border-[#F0E8DC] hover:shadow-[0_4px_20px_rgba(201,169,110,0.1)] transition-all duration-300 flex flex-col items-center text-center rounded-sm">
            <div className="w-12 h-12 rounded-full bg-[#F9F5F0] flex items-center justify-center mb-6 border border-[#E8DDD0]">
              <Users className="w-5 h-5 text-[#C9A96E]" strokeWidth={1.5} />
            </div>
            <h3 className="text-[1.02rem] font-display text-[#2C2826] mb-4">Consultation préalable</h3>
            <div className="w-6 h-px bg-[#C9A96E] mb-4 opacity-40"></div>
            <p className="text-[0.82rem] leading-7 text-[#6B5C4E] tracking-[0.02em] font-body">
              Chaque rendez-vous débute par une consultation personnalisée pour un soin sur-mesure, adapté à votre peau et vos besoins.
            </p>
          </div>

          <div className="bg-white p-8 border border-[#F0E8DC] hover:shadow-[0_4px_20px_rgba(201,169,110,0.1)] transition-all duration-300 flex flex-col items-center text-center rounded-sm">
            <div className="w-12 h-12 rounded-full bg-[#F9F5F0] flex items-center justify-center mb-6 border border-[#E8DDD0]">
              <ClipboardCheck className="w-5 h-5 text-[#C9A96E]" strokeWidth={1.5} />
            </div>
            <h3 className="text-[1.02rem] font-display text-[#2C2826] mb-4">Conformité suisse</h3>
            <div className="w-6 h-px bg-[#C9A96E] mb-4 opacity-40"></div>
            <p className="text-[0.82rem] leading-7 text-[#6B5C4E] tracking-[0.02em] font-body">
              Mon cabinet respecte les exigences réglementaires suisses les plus strictes en matière d&apos;hygiène et de salubrité.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default EngagementSection;
