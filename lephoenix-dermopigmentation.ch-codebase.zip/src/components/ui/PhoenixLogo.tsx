export default function PhoenixLogo({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 100 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-label="Le Phoenix"
    >
      {/* === FLAMMES BASE === */}
      <path d="M50 112 C47 106 43 99 45 91 C41 97 39 105 42 113 C37 107 36 98 40 90 C35 96 34 104 37 112" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" fill="none" opacity="0.45"/>
      <path d="M50 112 C53 106 57 99 55 91 C59 97 61 105 58 113 C63 107 64 98 60 90 C65 96 66 104 63 112" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" fill="none" opacity="0.45"/>
      <path d="M50 110 C50 104 50 98 50 90" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" fill="none" opacity="0.55"/>

      {/* === QUEUE === */}
      <path d="M43 82 C40 88 35 94 31 102" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" fill="none"/>
      <path d="M50 84 C50 91 50 97 50 104" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" fill="none"/>
      <path d="M57 82 C60 88 65 94 69 102" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" fill="none"/>
      {/* petites plumes de queue */}
      <path d="M44 87 C41 90 39 94 40 98" stroke="currentColor" strokeWidth="0.7" strokeLinecap="round" fill="none" opacity="0.5"/>
      <path d="M56 87 C59 90 61 94 60 98" stroke="currentColor" strokeWidth="0.7" strokeLinecap="round" fill="none" opacity="0.5"/>

      {/* === CORPS === */}
      <ellipse cx="50" cy="64" rx="9" ry="16" stroke="currentColor" strokeWidth="1.5" fill="none"/>
      {/* détail plumes corps */}
      <path d="M41 60 C44 57 47 58 49 62" stroke="currentColor" strokeWidth="0.7" strokeLinecap="round" fill="none" opacity="0.4"/>
      <path d="M59 60 C56 57 53 58 51 62" stroke="currentColor" strokeWidth="0.7" strokeLinecap="round" fill="none" opacity="0.4"/>
      <path d="M41 68 C44 65 47 66 49 70" stroke="currentColor" strokeWidth="0.7" strokeLinecap="round" fill="none" opacity="0.4"/>
      <path d="M59 68 C56 65 53 66 51 70" stroke="currentColor" strokeWidth="0.7" strokeLinecap="round" fill="none" opacity="0.4"/>

      {/* === AILE GAUCHE === */}
      <path d="M41 60 C32 53 18 50 6 42 C11 47 9 55 14 58 C7 55 2 60 5 68 C10 63 15 65 20 62 C13 68 11 76 16 81 C21 73 28 70 33 68 C26 75 26 83 31 87 C36 78 41 73 41 70" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
      {/* plumes aile gauche */}
      <path d="M20 57 C25 54 30 57 32 62" stroke="currentColor" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.55"/>
      <path d="M13 65 C18 62 23 65 25 70" stroke="currentColor" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.55"/>
      <path d="M17 75 C22 72 27 75 28 80" stroke="currentColor" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.55"/>

      {/* === AILE DROITE === */}
      <path d="M59 60 C68 53 82 50 94 42 C89 47 91 55 86 58 C93 55 98 60 95 68 C90 63 85 65 80 62 C87 68 89 76 84 81 C79 73 72 70 67 68 C74 75 74 83 69 87 C64 78 59 73 59 70" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
      {/* plumes aile droite */}
      <path d="M80 57 C75 54 70 57 68 62" stroke="currentColor" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.55"/>
      <path d="M87 65 C82 62 77 65 75 70" stroke="currentColor" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.55"/>
      <path d="M83 75 C78 72 73 75 72 80" stroke="currentColor" strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.55"/>

      {/* === COU === */}
      <path d="M44 48 C43 41 44 34 50 28" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" fill="none"/>
      <path d="M56 48 C57 41 56 34 50 28" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" fill="none"/>

      {/* === TÊTE === */}
      <circle cx="50" cy="23" r="9" stroke="currentColor" strokeWidth="1.5" fill="none"/>

      {/* === BEC === */}
      <path d="M50 21 L57 18 L50 25" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" fill="none"/>

      {/* === ŒIL === */}
      <circle cx="52" cy="21" r="1.5" fill="currentColor"/>
      <circle cx="52.5" cy="20.5" r="0.4" fill="none" stroke="currentColor" strokeWidth="0.3"/>

      {/* === CRÊTE / COURONNE === */}
      <path d="M45 15 C43 8 46 3 50 1" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" fill="none"/>
      <path d="M50 14 C50 7 50 3 50 0" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" fill="none"/>
      <path d="M55 15 C57 8 54 3 50 1" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" fill="none"/>
      {/* perles de couronne */}
      <circle cx="45" cy="14" r="1.2" fill="currentColor" opacity="0.8"/>
      <circle cx="50" cy="13" r="1.2" fill="currentColor" opacity="0.8"/>
      <circle cx="55" cy="14" r="1.2" fill="currentColor" opacity="0.8"/>
    </svg>
  );
}
