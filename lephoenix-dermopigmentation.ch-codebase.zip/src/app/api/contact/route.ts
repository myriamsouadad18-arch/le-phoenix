import { NextRequest, NextResponse } from "next/server";
import { Resend } from "resend";

const resend = new Resend("re_bhUzUEzy_QBmUuy4EUeXZWBmZwqEEZeQr");

export async function POST(req: NextRequest) {
  try {
    const { name, email, phone, service, message } = await req.json();

    if (!name || !email || !message) {
      return NextResponse.json({ error: "Champs requis manquants" }, { status: 400 });
    }

    const { error } = await resend.emails.send({
      from: "Le Phoenix <onboarding@resend.dev>",
      to: ["myriamsouadad18@gmail.com"],
      replyTo: email,
      subject: `Nouvelle demande de rendez-vous — ${name}`,
      html: `
        <!DOCTYPE html>
        <html lang="fr">
        <head>
          <meta charset="UTF-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        </head>
        <body style="margin:0;padding:0;background:#FDFCFA;font-family:Georgia,serif;">
          <table width="100%" cellpadding="0" cellspacing="0" style="background:#FDFCFA;padding:40px 0;">
            <tr>
              <td align="center">
                <table width="600" cellpadding="0" cellspacing="0" style="background:#FFFFFF;border:1px solid #E8D9C5;max-width:600px;">
                  <!-- Header -->
                  <tr>
                    <td style="background:linear-gradient(135deg,#C9A882,#D4A86A);padding:40px;text-align:center;">
                      <h1 style="margin:0;color:#FFFFFF;font-family:Georgia,serif;font-size:28px;font-weight:400;letter-spacing:0.2em;">
                        LE PHOENIX
                      </h1>
                      <p style="margin:8px 0 0;color:rgba(255,255,255,0.85);font-family:Arial,sans-serif;font-size:12px;letter-spacing:0.15em;text-transform:uppercase;">
                        Nouvelle demande de rendez-vous
                      </p>
                    </td>
                  </tr>
                  <!-- Body -->
                  <tr>
                    <td style="padding:40px;">
                      <p style="margin:0 0 24px;color:#8A7A69;font-family:Arial,sans-serif;font-size:13px;line-height:1.6;">
                        Vous avez reçu une nouvelle demande de rendez-vous via le site Le Phoenix.
                      </p>

                      <table width="100%" cellpadding="0" cellspacing="0">
                        <tr>
                          <td style="border-bottom:1px solid #E8D9C5;padding:14px 0;">
                            <span style="display:block;font-family:Arial,sans-serif;font-size:10px;letter-spacing:0.2em;text-transform:uppercase;color:#C9A882;margin-bottom:4px;">Nom</span>
                            <span style="font-family:Georgia,serif;font-size:16px;color:#2C2519;">${name}</span>
                          </td>
                        </tr>
                        <tr>
                          <td style="border-bottom:1px solid #E8D9C5;padding:14px 0;">
                            <span style="display:block;font-family:Arial,sans-serif;font-size:10px;letter-spacing:0.2em;text-transform:uppercase;color:#C9A882;margin-bottom:4px;">E-mail</span>
                            <span style="font-family:Georgia,serif;font-size:16px;color:#2C2519;">${email}</span>
                          </td>
                        </tr>
                        ${
                          phone
                            ? `<tr>
                          <td style="border-bottom:1px solid #E8D9C5;padding:14px 0;">
                            <span style="display:block;font-family:Arial,sans-serif;font-size:10px;letter-spacing:0.2em;text-transform:uppercase;color:#C9A882;margin-bottom:4px;">Téléphone</span>
                            <span style="font-family:Georgia,serif;font-size:16px;color:#2C2519;">${phone}</span>
                          </td>
                        </tr>`
                            : ""
                        }
                        ${
                          service
                            ? `<tr>
                          <td style="border-bottom:1px solid #E8D9C5;padding:14px 0;">
                            <span style="display:block;font-family:Arial,sans-serif;font-size:10px;letter-spacing:0.2em;text-transform:uppercase;color:#C9A882;margin-bottom:4px;">Service souhaité</span>
                            <span style="font-family:Georgia,serif;font-size:16px;color:#2C2519;">${service}</span>
                          </td>
                        </tr>`
                            : ""
                        }
                        <tr>
                          <td style="padding:14px 0;">
                            <span style="display:block;font-family:Arial,sans-serif;font-size:10px;letter-spacing:0.2em;text-transform:uppercase;color:#C9A882;margin-bottom:8px;">Message</span>
                            <p style="margin:0;font-family:Arial,sans-serif;font-size:14px;color:#5C4F3D;line-height:1.8;white-space:pre-wrap;">${message}</p>
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                  <!-- Footer -->
                  <tr>
                    <td style="background:#F5EFE6;padding:24px 40px;text-align:center;border-top:1px solid #E8D9C5;">
                      <p style="margin:0;font-family:Arial,sans-serif;font-size:11px;color:#8A7A69;letter-spacing:0.1em;">
                        Le Phoenix · Cabinet de dermopigmentation · Genève, Suisse
                      </p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
        </body>
        </html>
      `,
    });

    if (error) {
      console.error("Resend error:", error);
      return NextResponse.json({ error: "Échec de l'envoi" }, { status: 500 });
    }

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("Contact API error:", err);
    return NextResponse.json({ error: "Erreur serveur" }, { status: 500 });
  }
}
