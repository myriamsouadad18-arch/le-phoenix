import Navbar from "@/components/sections/Navbar";
import Hero from "@/components/sections/Hero";
import About from "@/components/sections/About";
import ServicesSection from "@/components/sections/Services";
import EngagementSection from "@/components/sections/Engagement";
import Contact from "@/components/sections/Contact";
import Footer from "@/components/sections/Footer";

export default function Home() {
  return (
    <main className="min-h-screen bg-[#F9F5F0]">
      <Navbar />
      <Hero />
      <About />
      <ServicesSection />
      <EngagementSection />
      <Contact />
      <Footer />
    </main>
  );
}
