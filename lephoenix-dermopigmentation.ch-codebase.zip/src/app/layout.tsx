import type { Metadata } from "next";
import "./globals.css";
import { VisualEditsMessenger } from "orchids-visual-edits";

export const metadata: Metadata = {
  title: "Le Phoenix — Dermopigmentation Réparatrice & Esthétique | Genève, Suisse",
  description:
    "Cabinet de dermopigmentation haut de gamme à Genève. Reconstruction aréole 3D, camouflage correctif, sublimation des lèvres. Par Myriam — un espace sûr pour votre renaissance.",
  keywords: [
    "dermopigmentation",
    "Genève",
    "reconstruction aréole",
    "camouflage cicatrices",
    "vitiligo",
    "micropigmentation",
    "Suisse",
    "Le Phoenix",
  ],
  openGraph: {
    title: "Le Phoenix — Dermopigmentation Réparatrice & Esthétique | Genève",
    description:
      "L'art de la renaissance par la peau. Expertise en repigmentation cutanée réparatrice et esthétique à Genève.",
    locale: "fr_CH",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr">
      <body className="antialiased">
        {children}
        <VisualEditsMessenger />
      </body>
    </html>
  );
}
